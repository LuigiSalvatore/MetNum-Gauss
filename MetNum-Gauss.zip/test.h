#ifndef _LOGICA_MAT_H
#define _LOGICA_MAT_H
#include <math.h>
#include <iostream>

void gauss(double **a, double *b);
#endif // _LOGICA_MAT_H